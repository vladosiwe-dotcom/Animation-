particle dust_color_transition{from_color:[0.75f,0.9f,1f],to_color:[0.4f,0.6f,1f],scale:1f} ~0.4966 ~1.3059 ~3.2051 0.05 0.05 0.05 0.01 2 force @a
