title @a[tag=rz.viewer] times 4 30 8
title @a[tag=rz.viewer] subtitle ["",{"text":"Волшебница: ","color":"light_purple","bold":true},{"text":"Эль Хума!","color":"white"}]
title @a[tag=rz.viewer] title {"text":""}
particle snowflake ~1.4899 ~1.1906 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~1.4008 ~1.5811 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~1.151 ~1.8943 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~0.7902 ~2.0681 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~0.3896 ~2.0681 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~0.0287 ~1.8943 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~-0.221 ~1.5811 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~-0.3101 ~1.1906 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~-0.221 ~0.8001 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~0.0287 ~0.487 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~0.3896 ~0.3132 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~0.7902 ~0.3132 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~1.151 ~0.487 ~1.8015 0 0 0 0 1 force @a
particle snowflake ~1.4008 ~0.8001 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~1.1399 ~1.1906 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~0.9788 ~1.5796 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~0.5899 ~1.7406 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~0.201 ~1.5796 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~0.0399 ~1.1906 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~0.201 ~0.8017 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~0.5899 ~0.6406 ~1.8015 0 0 0 0 1 force @a
particle end_rod ~0.9788 ~0.8017 ~1.8015 0 0 0 0 1 force @a
