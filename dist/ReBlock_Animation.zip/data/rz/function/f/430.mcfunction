particle squid_ink ~2.2 ~0.1 ~7 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~1.7798 ~0.1 ~8.2931 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~0.6798 ~0.1 ~9.0923 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~-0.6798 ~0.1 ~9.0923 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~-1.7798 ~0.1 ~8.2931 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~-2.2 ~0.1 ~7 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~-1.7798 ~0.1 ~5.7069 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~-0.6798 ~0.1 ~4.9077 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~0.6798 ~0.1 ~4.9077 0.05 0.05 0.05 0.01 1 force @a
particle squid_ink ~1.7798 ~0.1 ~5.7069 0.05 0.05 0.05 0.01 1 force @a
particle dust_color_transition{from_color:[0.25,0,0.35],to_color:[0.02,0,0.03],scale:2.2} ~ ~0.6 ~7 1.2 0.6 1.2 0 6 force @a
data merge entity @e[type=block_display,tag=rz.cult.torso,limit=1] {transformation:[-0.4376f,0.069f,0f,0.2188f,0.0426f,0.6086f,0.0824f,0.5975f,0.0172f,0.2459f,-0.204f,0.0934f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.arm_r,limit=1] {transformation:[-0.0477f,-0.531f,0.0098f,0.8315f,0.1794f,-0.1354f,0.0256f,1.1758f,-0.0223f,0.0468f,0.185f,0.0822f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.hand_r,limit=1] {transformation:[-0.0435f,-0.1062f,0.0089f,0.9361f,0.1636f,-0.0271f,0.0233f,1.2119f,-0.0203f,0.0094f,0.1687f,0.08f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.arm_l,limit=1] {transformation:[-0.0795f,0.497f,0.0098f,-0.628f,-0.167f,-0.2355f,0.0256f,1.4928f,0.0273f,0.0063f,0.185f,0.1155f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.hand_l,limit=1] {transformation:[-0.0725f,0.0994f,0.0089f,-0.7305f,-0.1523f,-0.0471f,0.0233f,1.5337f,0.0249f,0.0013f,0.1687f,0.1236f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.head,limit=1] {transformation:[-0.3499f,0.3489f,0.0297f,0.2291f,0.2087f,0.1741f,0.4137f,0.9574f,0.2812f,0.3049f,-0.2702f,0.2404f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.robe,limit=1] {transformation:[-0.547f,0.0719f,0f,0.2074f,0.0533f,0.6339f,0.1442f,-0.022f,0.0215f,0.2561f,-0.357f,-0.0679f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p11,limit=1] {transformation:[-0.1094f,0.1351f,0f,-0.0114f,0.0107f,1.1918f,0.0031f,0.1425f,0.0043f,0.4815f,-0.0076f,-0.4137f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p12,limit=1] {transformation:[-0.4485f,0.0092f,0f,0.2846f,0.0437f,0.0811f,0.0865f,1.1274f,0.0177f,0.0328f,-0.2142f,0.3134f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p13,limit=1] {transformation:[-0.3732f,0.1783f,0.0317f,0.4336f,0.2226f,0.089f,0.4413f,1.0334f,0.2999f,0.1558f,-0.2882f,0.4094f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p14,limit=1] {transformation:[-0.381f,0.3101f,0.0049f,0.2821f,0.2273f,0.1548f,0.0689f,0.9491f,0.3062f,0.271f,-0.045f,0.2738f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p15,limit=1] {transformation:[-0.0233f,0.2132f,0.03f,0.3028f,0.0139f,0.1064f,0.4183f,0.9771f,0.0187f,0.1863f,-0.2732f,0.2787f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p16,limit=1] {transformation:[-0.0233f,0.2132f,0.03f,-0.0549f,0.0139f,0.1064f,0.4183f,1.1905f,0.0187f,0.1863f,-0.2732f,0.5661f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p17,limit=1] {transformation:[-0.3499f,0.031f,0.0013f,0.5146f,0.2087f,0.0155f,0.0184f,1.4988f,0.2812f,0.0271f,-0.012f,0.1938f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p18,limit=1] {transformation:[-0.1011f,0.1163f,0.0002f,0.3207f,0.0603f,0.058f,0.0028f,1.4403f,0.0812f,0.1016f,-0.0018f,0.083f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p19,limit=1] {transformation:[-0.0311f,0.0388f,0.0004f,0.3207f,0.0186f,0.0193f,0.0055f,1.4795f,0.025f,0.0339f,-0.0036f,0.141f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p20,limit=1] {transformation:[-0.1011f,0.1163f,0.0002f,0.1419f,0.0603f,0.058f,0.0028f,1.547f,0.0812f,0.1016f,-0.0018f,0.2267f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p21,limit=1] {transformation:[-0.0311f,0.0388f,0.0004f,0.1418f,0.0186f,0.0193f,0.0055f,1.5862f,0.025f,0.0339f,-0.0036f,0.2847f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p22,limit=1] {transformation:[-0.2021f,0.0388f,0.0003f,0.2159f,0.1206f,0.0193f,0.0037f,1.4306f,0.1624f,0.0339f,-0.0024f,0.0567f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
data merge entity @e[type=block_display,tag=rz.cult.p23,limit=1] {transformation:[-0.171f,0.0155f,0.0003f,0.2159f,0.102f,0.0077f,0.0046f,1.4486f,0.1375f,0.0136f,-0.003f,0.0821f,0f,0f,0f,1f],start_interpolation:0,interpolation_duration:10}
execute as @a[tag=rz.viewer] at @s run playsound minecraft:entity.witch.celebrate master @s ~ ~ ~ 1 0.55
