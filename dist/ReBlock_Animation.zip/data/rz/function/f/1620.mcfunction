function rz:finish
